#!/usr/bin/env python3
"""Сайт «Насколько ты похож на картошку» — сервер без внешних зависимостей
(нужен только Python 3 и Pillow для обработки фото)."""
import base64
import binascii
import hashlib
import hmac
import io
import json
import mimetypes
import os
import random
import re
import secrets
import sqlite3
import time
import unicodedata
from datetime import datetime, timezone
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Lock

from PIL import Image, ImageOps

BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"
DATA = BASE / "data"
UPLOADS = DATA / "uploads"
DB_PATH = DATA / "potato.db"
UPLOADS.mkdir(parents=True, exist_ok=True)

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8000"))
MAX_BODY = 8 * 1024 * 1024
SESSION_TTL = 30 * 24 * 3600
PBKDF2_ITER = 200_000

LOGIN_RE = re.compile(r"^[A-Za-z0-9_.-]{3,24}$")
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[^@\s]{2,}$")

# ---------------------------------------------------------------- результат
CAPTION_80 = "агай я протестую 🫡"
CAPTION_60 = "что за краш 😍🥔"


def result_info(percent):
    """Подпись и фото-двойник для процента."""
    if percent >= 80:
        return CAPTION_80, "/static/photo80.jpg"
    if percent >= 60:
        return CAPTION_60, "/static/photo60.jpg"
    if percent >= 40:
        return "Почти пюре 🥣", None
    if percent >= 20:
        return "Есть что-то земляное 🌱", None
    return "Даже картошка обиделась 🥔💔", None


# ---------------------------------------------------------------- база
def db():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def init_db():
    con = db()
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            login TEXT NOT NULL UNIQUE COLLATE NOCASE,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            nick TEXT NOT NULL UNIQUE COLLATE NOCASE,
            pw_salt BLOB NOT NULL,
            pw_hash BLOB NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0,
            avatar_photo_id INTEGER,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            percent INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS photos_user ON photos(user_id, id);
        """
    )
    con.commit()
    con.close()


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def hash_password(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITER)


def token_hash(token):
    return hashlib.sha256(token.encode()).hexdigest()


# ---------------------------------------------------------------- ограничения
_throttle = {}
_throttle_lock = Lock()


def throttled(key, limit, window):
    """True, если за окно (сек) уже было `limit` событий. Иначе записывает событие."""
    now = time.time()
    with _throttle_lock:
        arr = [t for t in _throttle.get(key, []) if now - t < window]
        if len(arr) >= limit:
            _throttle[key] = arr
            return True
        arr.append(now)
        _throttle[key] = arr
        return False


def failures_exceeded(key, limit, window):
    now = time.time()
    with _throttle_lock:
        arr = [t for t in _throttle.get(key, []) if now - t < window]
        _throttle[key] = arr
        return len(arr) >= limit


def add_failure(key):
    with _throttle_lock:
        _throttle.setdefault(key, []).append(time.time())


# ---------------------------------------------------------------- вспомогательное
class ApiError(Exception):
    def __init__(self, code, message):
        self.code = code
        self.message = message


def clean_nick(nick):
    nick = " ".join(str(nick).split())
    if not 2 <= len(nick) <= 24:
        raise ApiError(400, "Ник: от 2 до 24 символов")
    if any(unicodedata.category(c).startswith("C") for c in nick):
        raise ApiError(400, "В нике есть недопустимые символы")
    return nick


def photo_json(row, viewer):
    caption, ref = result_info(row["percent"])
    can_delete = bool(viewer and (viewer["is_admin"] or viewer["id"] == row["user_id"]))
    return {
        "id": row["id"],
        "url": f"/uploads/{row['id']}.jpg",
        "percent": row["percent"],
        "caption": caption,
        "ref": ref,
        "created_at": row["created_at"],
        "can_delete": can_delete,
    }


def avatar_url(con, user):
    pid = user["avatar_photo_id"]
    if pid:
        ok = con.execute("SELECT 1 FROM photos WHERE id=? AND user_id=?", (pid, user["id"])).fetchone()
        if ok:
            return f"/uploads/{pid}.jpg"
    last = con.execute("SELECT id FROM photos WHERE user_id=? ORDER BY id DESC LIMIT 1", (user["id"],)).fetchone()
    return f"/uploads/{last['id']}.jpg" if last else None


def me_json(con, user):
    if not user:
        return None
    return {
        "id": user["id"],
        "nick": user["nick"],
        "email": user["email"],
        "is_admin": bool(user["is_admin"]),
        "avatar": avatar_url(con, user),
    }


def process_image(data_url):
    if not isinstance(data_url, str) or "," not in data_url:
        raise ApiError(400, "Не удалось прочитать фото")
    head, b64 = data_url.split(",", 1)
    if not head.startswith("data:image/"):
        raise ApiError(400, "Нужна картинка")
    try:
        raw = base64.b64decode(b64, validate=False)
    except (binascii.Error, ValueError):
        raise ApiError(400, "Фото повреждено")
    if len(raw) > 6 * 1024 * 1024:
        raise ApiError(413, "Фото слишком большое (максимум 6 МБ)")
    try:
        img = Image.open(io.BytesIO(raw))
        if img.format not in ("JPEG", "PNG", "WEBP"):
            raise ApiError(400, "Поддерживаются JPG, PNG и WEBP")
        img = ImageOps.exif_transpose(img).convert("RGB")
    except ApiError:
        raise
    except Exception:
        raise ApiError(400, "Это не похоже на картинку")
    img.thumbnail((900, 900))
    out = io.BytesIO()
    img.save(out, "JPEG", quality=85)  # заново кодируем: метаданные (геолокация и т.п.) пропадают
    return out.getvalue()


# ---------------------------------------------------------------- HTTP
class Handler(BaseHTTPRequestHandler):
    server_version = "PotatoSite/1.0"
    protocol_version = "HTTP/1.0"

    # --- общее
    def log_message(self, fmt, *args):
        pass

    def client_ip(self):
        return self.client_address[0]

    def secure_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data: blob:; style-src 'self'; script-src 'self'; "
            "frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
        )

    def send_json(self, code, obj, headers=None):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.secure_headers()
        for k, v in (headers or []):
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        ctype = self.headers.get("Content-Type", "")
        if not ctype.lower().startswith("application/json"):
            raise ApiError(415, "Нужен JSON")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(400, "Неверная длина запроса")
        if length > MAX_BODY:
            raise ApiError(413, "Запрос слишком большой")
        try:
            data = json.loads(self.rfile.read(length) or b"{}")
        except ValueError:
            raise ApiError(400, "Неверный JSON")
        if not isinstance(data, dict):
            raise ApiError(400, "Неверный JSON")
        return data

    def is_https(self):
        return self.headers.get("X-Forwarded-Proto", "").lower() == "https"

    def session_cookie(self, token, max_age):
        parts = [f"sid={token}", "Path=/", "HttpOnly", "SameSite=Lax", f"Max-Age={max_age}"]
        if self.is_https():
            parts.append("Secure")
        return ("Set-Cookie", "; ".join(parts))

    def current_user(self, con):
        raw = self.headers.get("Cookie")
        if not raw:
            return None
        try:
            c = SimpleCookie(raw)
        except Exception:
            return None
        if "sid" not in c:
            return None
        row = con.execute(
            "SELECT u.*, s.created_at AS s_created FROM sessions s JOIN users u ON u.id = s.user_id "
            "WHERE s.token_hash = ?",
            (token_hash(c["sid"].value),),
        ).fetchone()
        if not row:
            return None
        if time.time() - row["s_created"] > SESSION_TTL:
            con.execute("DELETE FROM sessions WHERE token_hash = ?", (token_hash(c["sid"].value),))
            con.commit()
            return None
        return row

    def require_user(self, con):
        user = self.current_user(con)
        if not user:
            raise ApiError(401, "Нужно войти")
        return user

    # --- маршрутизация
    def dispatch(self, method):
        path = self.path.split("?", 1)[0]
        query = self.path.split("?", 1)[1] if "?" in self.path else ""
        try:
            if path.startswith("/api/"):
                self.api(method, path, query)
            elif method == "GET":
                self.static(path)
            else:
                raise ApiError(405, "Метод не поддерживается")
        except ApiError as e:
            self.send_json(e.code, {"error": e.message})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:  # не отдаём внутренности наружу
            print("ERROR", method, self.path, repr(e))
            try:
                self.send_json(500, {"error": "Ошибка сервера"})
            except Exception:
                pass

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def do_DELETE(self):
        self.dispatch("DELETE")

    # --- статика и фото
    def static(self, path):
        if path in ("/", "/index.html"):
            return self.send_file(STATIC / "index.html", "no-cache")
        m = re.fullmatch(r"/uploads/(\d+)\.jpg", path)
        if m:
            return self.send_file(UPLOADS / f"{int(m.group(1))}.jpg", "public, max-age=3600")
        m = re.fullmatch(r"/static/([A-Za-z0-9_.-]+)", path)
        if m:
            return self.send_file(STATIC / m.group(1), "no-cache")
        raise ApiError(404, "Не найдено")

    def send_file(self, file, cache):
        if not file.is_file():
            raise ApiError(404, "Не найдено")
        body = file.read_bytes()
        ctype = mimetypes.guess_type(file.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
            ctype += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.secure_headers()
        self.end_headers()
        self.wfile.write(body)

    # --- API
    def api(self, method, path, query):
        con = db()
        try:
            self.api_inner(con, method, path, query)
        finally:
            con.close()

    def api_inner(self, con, method, path, query):
        if method == "POST" and path == "/api/register":
            return self.register(con)
        if method == "POST" and path == "/api/login":
            return self.login(con)
        if method == "POST" and path == "/api/logout":
            return self.logout(con)
        if method == "GET" and path == "/api/me":
            return self.send_json(200, {"user": me_json(con, self.current_user(con))})
        if method == "POST" and path == "/api/upload":
            return self.upload(con)
        if method == "GET" and path == "/api/feed":
            return self.feed(con, query)
        if method == "POST" and path == "/api/avatar":
            return self.set_avatar(con)
        m = re.fullmatch(r"/api/users/(\d+)", path)
        if method == "GET" and m:
            return self.profile(con, int(m.group(1)))
        m = re.fullmatch(r"/api/photos/(\d+)", path)
        if method == "DELETE" and m:
            return self.delete_photo(con, int(m.group(1)))
        raise ApiError(404, "Не найдено")

    def start_session(self, con, user_id):
        token = secrets.token_urlsafe(32)
        con.execute(
            "INSERT INTO sessions(token_hash, user_id, created_at) VALUES (?,?,?)",
            (token_hash(token), user_id, int(time.time())),
        )
        con.execute("DELETE FROM sessions WHERE created_at < ?", (int(time.time()) - SESSION_TTL,))
        con.commit()
        return self.session_cookie(token, SESSION_TTL)

    def register(self, con):
        if throttled(("reg", self.client_ip()), 10, 3600):
            raise ApiError(429, "Слишком много регистраций, попробуй позже")
        d = self.read_json()
        login = str(d.get("login", "")).strip()
        email = str(d.get("email", "")).strip()
        password = str(d.get("password", ""))
        nick = clean_nick(d.get("nick", ""))
        if not LOGIN_RE.match(login):
            raise ApiError(400, "Логин: 3–24 символа, латиница, цифры и . _ -")
        if len(email) > 254 or not EMAIL_RE.match(email):
            raise ApiError(400, "Проверь почту")
        if not 6 <= len(password) <= 128:
            raise ApiError(400, "Пароль: от 6 до 128 символов")
        if con.execute("SELECT 1 FROM users WHERE login = ?", (login,)).fetchone():
            raise ApiError(409, "Такой логин уже занят")
        if con.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
            raise ApiError(409, "Эта почта уже зарегистрирована")
        if con.execute("SELECT 1 FROM users WHERE nick = ?", (nick,)).fetchone():
            raise ApiError(409, "Такой ник уже занят")
        salt = secrets.token_bytes(16)
        is_admin = 1 if con.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0 else 0
        try:
            cur = con.execute(
                "INSERT INTO users(login,email,nick,pw_salt,pw_hash,is_admin,created_at) VALUES (?,?,?,?,?,?,?)",
                (login, email, nick, salt, hash_password(password, salt), is_admin, now_iso()),
            )
            con.commit()
        except sqlite3.IntegrityError:
            raise ApiError(409, "Логин, почта или ник уже заняты")
        cookie = self.start_session(con, cur.lastrowid)
        user = con.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
        self.send_json(200, {"user": me_json(con, user)}, [cookie])

    def login(self, con):
        d = self.read_json()
        login = str(d.get("login", "")).strip()
        password = str(d.get("password", ""))
        key = ("login", self.client_ip(), login.lower())
        if failures_exceeded(key, 8, 600):
            raise ApiError(429, "Слишком много попыток, подожди несколько минут")
        user = con.execute("SELECT * FROM users WHERE login = ? OR email = ?", (login, login)).fetchone()
        # хеш считаем всегда, чтобы время ответа не выдавало, существует ли логин
        salt = user["pw_salt"] if user else b"\0" * 16
        calc = hash_password(password, salt)
        if not user or not hmac.compare_digest(calc, user["pw_hash"]):
            add_failure(key)
            raise ApiError(401, "Неверный логин или пароль")
        cookie = self.start_session(con, user["id"])
        self.send_json(200, {"user": me_json(con, user)}, [cookie])

    def logout(self, con):
        raw = self.headers.get("Cookie")
        if raw:
            try:
                c = SimpleCookie(raw)
                if "sid" in c:
                    con.execute("DELETE FROM sessions WHERE token_hash = ?", (token_hash(c["sid"].value),))
                    con.commit()
            except Exception:
                pass
        self.send_json(200, {"ok": True}, [self.session_cookie("", 0)])

    def upload(self, con):
        user = self.require_user(con)
        if throttled(("up", user["id"]), 1, 3):
            raise ApiError(429, "Не так быстро")
        d = self.read_json()
        jpeg = process_image(d.get("image"))
        percent = random.randint(0, 100)
        cur = con.execute(
            "INSERT INTO photos(user_id, percent, created_at) VALUES (?,?,?)",
            (user["id"], percent, now_iso()),
        )
        pid = cur.lastrowid
        (UPLOADS / f"{pid}.jpg").write_bytes(jpeg)
        if not user["avatar_photo_id"]:
            con.execute("UPDATE users SET avatar_photo_id=? WHERE id=?", (pid, user["id"]))
        con.commit()
        row = con.execute("SELECT * FROM photos WHERE id=?", (pid,)).fetchone()
        self.send_json(200, {"photo": photo_json(row, user)})

    def feed(self, con, query):
        viewer = self.current_user(con)
        params = dict(p.split("=", 1) for p in query.split("&") if "=" in p)
        try:
            before = int(params.get("before", "0"))
        except ValueError:
            before = 0
        sql = (
            "SELECT p.*, u.nick, u.id AS uid, u.avatar_photo_id FROM photos p JOIN users u ON u.id = p.user_id "
            + ("WHERE p.id < ? " if before else "")
            + "ORDER BY p.id DESC LIMIT 21"
        )
        rows = con.execute(sql, (before,) if before else ()).fetchall()
        more = len(rows) > 20
        items = []
        for r in rows[:20]:
            item = photo_json(r, viewer)
            item["user"] = {"id": r["uid"], "nick": r["nick"]}
            items.append(item)
        self.send_json(200, {"items": items, "more": more})

    def profile(self, con, uid):
        viewer = self.current_user(con)
        user = con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        if not user:
            raise ApiError(404, "Пользователь не найден")
        rows = con.execute("SELECT * FROM photos WHERE user_id=? ORDER BY id DESC", (uid,)).fetchall()
        is_owner = bool(viewer and viewer["id"] == uid)
        data = {
            "id": user["id"],
            "nick": user["nick"],
            "created_at": user["created_at"],
            "avatar": avatar_url(con, user),
            "best": max((r["percent"] for r in rows), default=None),
            "count": len(rows),
            "photos": [photo_json(r, viewer) for r in rows],
            "is_owner": is_owner,
        }
        if is_owner:  # почта видна только владельцу
            data["email"] = user["email"]
        self.send_json(200, data)

    def set_avatar(self, con):
        user = self.require_user(con)
        d = self.read_json()
        try:
            pid = int(d.get("photo_id"))
        except (TypeError, ValueError):
            raise ApiError(400, "Неверное фото")
        if not con.execute("SELECT 1 FROM photos WHERE id=? AND user_id=?", (pid, user["id"])).fetchone():
            raise ApiError(404, "Фото не найдено")
        con.execute("UPDATE users SET avatar_photo_id=? WHERE id=?", (pid, user["id"]))
        con.commit()
        self.send_json(200, {"ok": True})

    def delete_photo(self, con, pid):
        user = self.require_user(con)
        row = con.execute("SELECT * FROM photos WHERE id=?", (pid,)).fetchone()
        if not row:
            raise ApiError(404, "Фото не найдено")
        if not (user["is_admin"] or row["user_id"] == user["id"]):
            raise ApiError(403, "Нет прав")
        con.execute("DELETE FROM photos WHERE id=?", (pid,))
        con.execute("UPDATE users SET avatar_photo_id=NULL WHERE avatar_photo_id=?", (pid,))
        con.commit()
        try:
            (UPLOADS / f"{pid}.jpg").unlink()
        except FileNotFoundError:
            pass
        self.send_json(200, {"ok": True})


def main():
    init_db()
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"Сайт запущен: http://localhost:{PORT}  (в локальной сети: http://<IP-компьютера>:{PORT})")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nОстановлено")


if __name__ == "__main__":
    main()
