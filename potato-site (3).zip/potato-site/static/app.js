"use strict";

const app = document.getElementById("app");
const nav = document.getElementById("nav");
const toastEl = document.getElementById("toast");
let me = null;

/* ---------- утилиты ---------- */
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add("show");
  clearTimeout(toast.t);
  toast.t = setTimeout(() => toastEl.classList.remove("show"), 2600);
}

async function api(method, url, body) {
  const opt = { method, headers: {}, credentials: "same-origin" };
  if (body !== undefined) {
    opt.headers["Content-Type"] = "application/json";
    opt.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(url, opt);
  } catch (e) {
    throw new Error("Нет связи с сервером");
  }
  let data = {};
  try { data = await res.json(); } catch (e) { /* пусто */ }
  if (!res.ok) throw new Error(data.error || "Что-то пошло не так");
  return data;
}

function fmtDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" });
}
function fmtDateTime(iso) {
  const d = new Date(iso);
  return d.toLocaleString("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

function avatar(url) {
  return url ? h("img", { class: "ava", src: url, alt: "" }) : h("span", { class: "ava ph" }, "🥔");
}

function go(hash) { location.hash = hash; }

/* ---------- шапка ---------- */
function renderNav() {
  const route = location.hash || "#/";
  const link = (href, text) => h("a", { href, class: route === href ? "active" : "" }, text);
  nav.replaceChildren(
    link("#/feed", "Лента"),
    me
      ? [link(`#/u/${me.id}`, me.nick), h("button", { onclick: logout }, "Выйти")]
      : [link("#/login", "Войти"), link("#/register", "Регистрация")]
  );
}

async function logout() {
  try { await api("POST", "/api/logout", {}); } catch (e) { /* ничего */ }
  me = null;
  go("#/");
  route();
}

/* ---------- страницы ---------- */
function pageHome() {
  const box = h("div");
  box.append(
    h("h1", null, "Насколько ты похож на картошку? 🥔"),
    h("p", { class: "lead" }, "Загрузи фото — узнаешь свой картофельный процент. Результат шуточный, не обижайся.")
  );
  if (!me) {
    box.append(
      h("div", { class: "card center" },
        h("p", null, "Чтобы загрузить фото, нужен аккаунт."),
        h("div", { class: "actions" },
          h("a", { class: "btn", href: "#/register" }, "Регистрация"),
          h("a", { class: "btn ghost", href: "#/login" }, "Войти"))
      )
    );
    return box;
  }
  box.append(uploader());
  return box;
}

function uploader() {
  const holder = h("div", { class: "card" });
  let dataUrl = null;

  const input = h("input", { type: "file", accept: "image/*" });
  const err = h("p", { class: "error" });
  const drop = h("label", { class: "drop" });
  const sendBtn = h("button", { class: "btn", type: "button", disabled: true }, "Узнать результат");
  const resetBtn = h("button", { class: "btn ghost", type: "button", hidden: true }, "Другое фото");

  function showPlaceholder() {
    dataUrl = null;
    drop.replaceChildren(
      h("div", { class: "big" }, "📸"),
      h("b", null, "Выбери или сфотографируй себя"),
      h("span", { class: "muted" }, "JPG, PNG или WEBP"),
      input
    );
    sendBtn.disabled = true;
    resetBtn.hidden = true;
  }

  async function pick(file) {
    err.textContent = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) { err.textContent = "Нужна картинка"; return; }
    try {
      dataUrl = await shrink(file);
    } catch (e) {
      err.textContent = "Не удалось открыть это фото";
      return;
    }
    drop.replaceChildren(h("img", { src: dataUrl, alt: "Твоё фото" }), input);
    sendBtn.disabled = false;
    resetBtn.hidden = false;
  }

  input.addEventListener("change", () => pick(input.files[0]));
  drop.addEventListener("dragover", (e) => { e.preventDefault(); drop.classList.add("over"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("over"));
  drop.addEventListener("drop", (e) => {
    e.preventDefault();
    drop.classList.remove("over");
    pick(e.dataTransfer.files[0]);
  });
  resetBtn.addEventListener("click", () => { input.value = ""; showPlaceholder(); });
  sendBtn.addEventListener("click", async () => {
    if (!dataUrl) return;
    sendBtn.disabled = true;
    sendBtn.textContent = "Считаем картошку…";
    err.textContent = "";
    try {
      const { photo } = await api("POST", "/api/upload", { image: dataUrl });
      showResult(holder, photo);
    } catch (e) {
      err.textContent = e.message;
      sendBtn.disabled = false;
      sendBtn.textContent = "Узнать результат";
    }
  });

  showPlaceholder();
  holder.append(drop, err, h("div", { class: "actions" }, sendBtn, resetBtn));
  return holder;
}

/* уменьшаем фото в браузере: быстрее грузится и экономит трафик */
function shrink(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const max = 900;
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * k);
      c.height = Math.round(img.height * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("bad image")); };
    img.src = url;
  });
}

function showResult(holder, p) {
  const num = h("div", { class: "percent" }, "0%");
  const fill = h("i");
  const caption = h("p", { class: "lead pop" }, p.caption);
  const pics = p.ref
    ? h("div", { class: "pair pop" },
        h("figure", null, h("img", { src: p.url, alt: "Ты" }), h("figcaption", null, "Ты")),
        h("figure", null, h("img", { src: p.ref, alt: "Картофельный двойник" }),
          h("figcaption", { class: "cap" }, p.caption)))
    : h("div", { class: "single pop" }, h("img", { src: p.url, alt: "Ты" }));

  holder.replaceChildren(
    h("div", { class: "result" },
      h("p", { class: "muted" }, "Ты похож на картошку на"),
      num,
      h("div", { class: "bar" }, fill),
      p.ref ? null : caption,
      pics,
      h("div", { class: "actions" },
        h("button", { class: "btn", onclick: () => { holder.replaceWith(uploader()); } }, "Ещё раз"),
        h("a", { class: "btn ghost", href: "#/feed" }, "В ленту"))
    )
  );

  requestAnimationFrame(() => { fill.style.width = p.percent + "%"; });
  const t0 = performance.now(), dur = 1400;
  (function tick(now) {
    const k = Math.min(1, (now - t0) / dur);
    num.textContent = Math.round(p.percent * (1 - Math.pow(1 - k, 3))) + "%";
    if (k < 1) requestAnimationFrame(tick);
  })(t0);
}

/* --- вход / регистрация --- */
function field(label, name, type, extra) {
  return h("label", null, label, h("input", { type, name, required: true, ...(extra || {}) }));
}

function authForm(title, fields, submitText, onSubmit, footer) {
  const err = h("p", { class: "error" });
  const btn = h("button", { class: "btn", type: "submit" }, submitText);
  const form = h("form", { novalidate: false }, fields, err, btn);
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    err.textContent = "";
    btn.disabled = true;
    try {
      await onSubmit(Object.fromEntries(new FormData(form)));
    } catch (ex) {
      err.textContent = ex.message;
      btn.disabled = false;
    }
  });
  return h("div", { class: "card narrow" }, h("h1", null, title), form, h("p", { class: "muted center" }, footer));
}

function pageLogin() {
  return authForm(
    "Вход",
    [
      field("Логин или почта", "login", "text", { autocomplete: "username" }),
      field("Пароль", "password", "password", { autocomplete: "current-password" }),
    ],
    "Войти",
    async (d) => {
      me = (await api("POST", "/api/login", d)).user;
      go("#/");
    },
    [ "Нет аккаунта? ", h("a", { href: "#/register" }, "Регистрация") ]
  );
}

function pageRegister() {
  return authForm(
    "Регистрация",
    [
      field("Ник (его увидят все)", "nick", "text", { autocomplete: "nickname", maxlength: 24, minlength: 2 }),
      field("Логин (для входа)", "login", "text", { autocomplete: "username", maxlength: 24, minlength: 3, pattern: "[A-Za-z0-9_.\\-]+", title: "Латиница, цифры и . _ -" }),
      field("Почта", "email", "email", { autocomplete: "email" }),
      field("Пароль (от 6 символов)", "password", "password", { autocomplete: "new-password", minlength: 6 }),
      h("p", { class: "private" }, "Почту видишь только ты. Остальным показываются ник и фото."),
    ],
    "Создать аккаунт",
    async (d) => {
      me = (await api("POST", "/api/register", d)).user;
      go("#/");
    },
    [ "Уже есть аккаунт? ", h("a", { href: "#/login" }, "Войти") ]
  );
}

/* --- карточка фото --- */
function photoCard(p, opts) {
  const imgs = h("div", { class: "imgs" + (p.ref ? " two" : "") },
    h("img", { src: p.url, alt: "Фото", loading: "lazy" }),
    p.ref ? h("img", { src: p.ref, alt: "Картофельный двойник", loading: "lazy" }) : null,
    h("span", { class: "badge" }, p.percent + "%")
  );
  const card = h("article", { class: "card item" }, imgs, h("div", { class: "cap" }, p.caption));
  const meta = h("div", { class: "meta" });
  if (p.user) {
    meta.append(h("a", { class: "user", href: `#/u/${p.user.id}` }, avatar(null), h("span", null, p.user.nick)));
  }
  meta.append(h("span", { class: "muted" }, fmtDateTime(p.created_at)));
  card.append(meta);

  const tools = h("div", { class: "actions" });
  if (opts && opts.avatar) {
    tools.append(h("button", { class: "btn ghost small", onclick: async () => {
      try { await api("POST", "/api/avatar", { photo_id: p.id }); toast("Аватар обновлён"); opts.onChange(); }
      catch (e) { toast(e.message); }
    } }, "Сделать аватаром"));
  }
  if (p.can_delete) {
    tools.append(h("button", { class: "btn danger small", onclick: async () => {
      if (!confirm("Удалить это фото?")) return;
      try { await api("DELETE", `/api/photos/${p.id}`); card.remove(); toast("Удалено"); }
      catch (e) { toast(e.message); }
    } }, "Удалить"));
  }
  if (tools.children.length) card.append(tools);
  return card;
}

/* --- лента --- */
function pageFeed() {
  const box = h("div");
  const list = h("div", { class: "feed" });
  const more = h("div", { class: "more" });
  box.append(h("h1", null, "Последние загрузки"), list, more);
  let last = 0;

  async function load() {
    more.replaceChildren();
    try {
      const data = await api("GET", "/api/feed" + (last ? `?before=${last}` : ""));
      for (const p of data.items) { list.append(photoCard(p)); last = p.id; }
      if (!list.children.length) {
        list.replaceWith(h("p", { class: "empty" }, "Пока пусто. Загрузи первое фото! 🥔"));
      }
      if (data.more) more.append(h("button", { class: "btn ghost", onclick: load }, "Показать ещё"));
    } catch (e) {
      more.append(h("p", { class: "error" }, e.message));
    }
  }
  load();
  return box;
}

/* --- профиль --- */
function pageProfile(id) {
  const box = h("div");
  async function load() {
    let d;
    try { d = await api("GET", `/api/users/${id}`); }
    catch (e) { box.replaceChildren(h("p", { class: "empty" }, e.message)); return; }

    const head = h("div", { class: "card prof-head" },
      avatar(d.avatar),
      h("div", null,
        h("h1", null, d.nick),
        h("div", { class: "stats" },
          h("div", { class: "stat" }, d.best == null ? "—" : d.best + "%", h("small", null, "лучший результат")),
          h("div", { class: "stat" }, String(d.count), h("small", null, "загрузок")),
          h("div", { class: "stat" }, fmtDate(d.created_at), h("small", null, "на сайте с")),
          d.is_owner ? h("div", { class: "stat" }, d.email, h("small", null, "почта (видна только тебе)")) : null
        ))
    );
    const list = h("div", { class: "feed" }, d.photos.map((p) => photoCard(p, { avatar: d.is_owner, onChange: load })));
    box.replaceChildren(
      head,
      h("h2", null, "История загрузок"),
      d.photos.length ? list : h("p", { class: "empty" }, "Фото пока нет.")
    );
  }
  load();
  return box;
}

/* ---------- маршрутизация ---------- */
async function route() {
  renderNav();
  const hash = location.hash || "#/";
  let m;
  let page;
  if (hash === "#/") page = pageHome();
  else if (hash === "#/login") page = me ? pageHome() : pageLogin();
  else if (hash === "#/register") page = me ? pageHome() : pageRegister();
  else if (hash === "#/feed") page = pageFeed();
  else if ((m = hash.match(/^#\/u\/(\d+)$/))) page = pageProfile(m[1]);
  else page = h("p", { class: "empty" }, "Такой страницы нет");
  app.replaceChildren(page);
  window.scrollTo(0, 0);
}

window.addEventListener("hashchange", route);

(async function init() {
  try { me = (await api("GET", "/api/me")).user; } catch (e) { me = null; }
  route();
})();
