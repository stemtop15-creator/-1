@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PY=py
where py >nul 2>nul || set PY=python
%PY% -c "import PIL" >nul 2>nul || %PY% -m pip install pillow
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:8000"
%PY% server.py
pause
