#!/bin/sh
cd "$(dirname "$0")"
python3 -c "import PIL" 2>/dev/null || python3 -m pip install pillow
( sleep 2; (xdg-open http://localhost:8000 || open http://localhost:8000) >/dev/null 2>&1 ) &
python3 server.py
